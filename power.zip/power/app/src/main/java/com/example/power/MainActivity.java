package com.example.power;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ImageView;
import com.bumptech.glide.Glide;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Load and display the animated GIF using Glide
        ImageView animatedGif = findViewById(R.id.star_animated);
        Glide.with(this)
                .load(R.drawable.star_animated)
                .into(animatedGif);
    }
}
